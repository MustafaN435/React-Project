import React from "react"

export default function Interests(){
    return(
        <section className = "interests-section"> 
            <h3>Interests</h3>
            <p>Food expert. Music scholar. Reader. Internet fanatic. Bacon buff. Entrepreneur. Travel geek. Pop culture ninja. Coffee fanatic.</p>
        </section>
    )
}